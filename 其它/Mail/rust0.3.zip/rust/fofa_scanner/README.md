# FOFA日本邮箱扫描工具 (Rust版)

这是一个用Rust语言编写的FOFA扫描工具，用于从日本网站中提取邮箱地址。

## 功能特点

- 支持多种查询方式：domain、contact、form、profile、personal等
- 并行处理网页内容，提高扫描效率
- 智能过滤，只提取个人邮箱
- 结果保存为CSV和JSON格式
- 自动重试和错误处理
- 友好的命令行界面和进度显示

## 安装

```bash
# 克隆仓库
git clone https://github.com/yourusername/fofa_scanner.git
cd fofa_scanner

# 编译项目
cargo build --release
cargo build --target x86_64-pc-windows-gnu --release
```

## 使用方法

```bash
# 基本用法
./target/release/fofa_scanner -e your_fofa_email -k your_fofa_key

# 查看帮助
./target/release/fofa_scanner --help

# 完整参数示例
./target/release/fofa_scanner \
  -e your_fofa_email \
  -k your_fofa_key \
  -p 20 \
  -s 100 \
  -t domain contact personal \
  -w 15 \
  -o results
```

## 命令行参数

- `-e, --email`: FOFA账户邮箱（必需）
- `-k, --key`: FOFA API密钥（必需）
- `-p, --max-page`: 最大扫描页数（默认：10）
- `-s, --page-size`: 每页结果数（默认：100）
- `-t, --query-types`: 查询类型，可选值: default, domain, contact, form, profile, personal
- `-w, --workers`: 并发工作线程数（默认：10）
- `-o, --output`: 输出文件名，不含扩展名（默认：jp_emails）

## 环境变量

设置以下环境变量可以启用日志功能：

```bash
# 显示所有日志信息
export RUST_LOG=info

# 只显示错误和警告
export RUST_LOG=warn
```

## 示例输出

```
2023-06-01 12:34:56 - INFO - 正在使用查询类型: domain
2023-06-01 12:34:56 - INFO - FOFA查询语法: domain=".jp" && country="JP"
2023-06-01 12:34:57 - INFO - 正在获取第 1 页结果...
...
2023-06-01 12:35:10 - INFO - 共发现 532 个唯一主机
2023-06-01 12:35:10 - INFO - 处理批次 1/6...
2023-06-01 12:35:15 - INFO - 发现邮箱: person@example.jp
...
2023-06-01 12:38:42 - INFO - 扫描完成，共提取 78 个日本邮箱
2023-06-01 12:38:42 - INFO - 结果已保存到 jp_emails.csv
2023-06-01 12:38:42 - INFO - 结果已保存到 jp_emails.json
```

## 许可证

MIT 