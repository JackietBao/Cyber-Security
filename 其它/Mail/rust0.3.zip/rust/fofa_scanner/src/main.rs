use base64::{engine::general_purpose, Engine as _};
use clap::Parser;
use csv::Writer;
use log::{error, info, warn};
use regex::Regex;
use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::fs::File;
use std::io::Write;
use std::thread;
use std::time::Duration;
use std::sync::{Arc, Mutex};
use url::Url;
use rand::thread_rng;
use std::sync::mpsc;
use rand::Rng;

// 定义错误类型
#[derive(thiserror::Error, Debug)]
enum ScannerError {
    #[error("请求错误: {0}")]
    RequestError(#[from] reqwest::Error),
    
    #[error("IO错误: {0}")]
    IoError(#[from] std::io::Error),
    
    #[error("JSON错误: {0}")]
    JsonError(#[from] serde_json::Error),
    
    #[error("URL解析错误: {0}")]
    UrlParseError(#[from] url::ParseError),
    
    #[error("CSV错误: {0}")]
    CsvError(#[from] csv::Error),
    
    #[error("其他错误: {0}")]
    Other(String),
    
    #[error("正则表达式错误: {0}")]
    Regex(String),
}

// 定义命令行参数
#[derive(Parser, Debug)]
#[clap(
    name = "fofa_scanner",
    version = "0.1.0",
    author = "FOFA Scanner",
    about = "FOFA日本邮箱扫描工具"
)]
struct Args {
    #[clap(short = 'e', long = "email", help = "FOFA账户邮箱")]
    email: String,
    
    #[clap(short = 'k', long = "key", help = "FOFA API密钥")]
    key: String,
    
    #[clap(short = 'p', long = "max-page", default_value = "10", help = "最大扫描页数")]
    max_page: usize,
    
    #[clap(short = 's', long = "page-size", default_value = "100", help = "每页结果数")]
    page_size: usize,
    
    #[clap(short = 't', long = "query-types", help = "查询类型 (default, domain, contact, form, profile, personal, specific_jp_emails)")]
    query_types: Option<Vec<String>>,
    
    #[clap(short = 'w', long = "workers", default_value = "10", help = "并发工作线程数")]
    workers: usize,
    
    #[clap(short = 'o', long = "output", default_value = "jp_emails", help = "输出文件名（不含扩展名）")]
    output: String,
}

// 定义结果结构
#[derive(Debug, Serialize, Deserialize, Clone)]
struct EmailResult {
    host: String,
    email: String,
}

// FOFA API响应结构
#[derive(Debug, Deserialize)]
struct FofaResponse {
    error: Option<bool>,
    mode: Option<String>,
    page: Option<usize>,
    query: Option<String>,
    results: Option<Vec<Vec<String>>>,
    size: Option<usize>,
}

// 扫描器结构体
#[derive(Clone)]
struct FofaScanner {
    email: String,
    key: String,
    max_page: usize,
    page_size: usize,
    timeout: u64,
    max_workers: usize,
    base_url: String,
    client: Client,
    jp_email_pattern: Regex,
    personal_email_pattern: Regex,
    results: Arc<Mutex<Vec<EmailResult>>>,
}

impl FofaScanner {
    fn new(email: String, key: String, max_page: usize, page_size: usize, max_workers: usize) -> Self {
        let client = Client::builder()
            .timeout(Duration::from_secs(10))
            .danger_accept_invalid_certs(true)
            .build()
            .expect("创建HTTP客户端失败");
        
        FofaScanner {
            email,
            key,
            max_page,
            page_size,
            timeout: 10,
            max_workers,
            base_url: "http://107.173.248.176:18888/api/v1/search/all".to_string(),
            client,
            jp_email_pattern: Regex::new(r"[a-zA-Z0-9_.+-]+@([a-zA-Z0-9-]+\.)+[a-zA-Z0-9-]+").unwrap(),
            personal_email_pattern: Regex::new(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}").unwrap(),
            results: Arc::new(Mutex::new(Vec::new())),
        }
    }
    
    fn encode_query(&self, query: &str) -> String {
        general_purpose::STANDARD.encode(query.as_bytes())
    }
    
    fn build_query(&self, query_type: &str) -> String {
        match query_type {
            "domain" => String::from("domain=\".jp\" && country=\"JP\""),
            "contact" => String::from("country=\"JP\" && (body=\"お問い合わせ\" || body=\"contact\" || body=\"メール\")"),
            "form" => String::from("country=\"JP\" && (body=\"form\" && body=\"email\" && body=\"submit\")"),
            "profile" => String::from("country=\"JP\" && (body=\"プロフィール\" || body=\"profile\" || body=\"マイページ\")"),
            "personal" => String::from("country=\"JP\" && (body=\"メール\" || body=\"Email:\" || body=\"連絡先\" || body=\"ご連絡\" || body=\"担当者\" || body=\"スタッフ\" || body=\"メンバー\")"),
            "specific_jp_emails" => String::from("country=\"JP\" && (body=\"@docomo.ne.jp\" || body=\"@icloud.com\" || body=\"@po8.oninet.ne.jp\" || body=\"@softbank.ne.jp\" || body=\"@hidaka-print.com\" || body=\"@ac.auone-net.jp\" || body=\"@nifty.com\" || body=\"@kjd.biglobe.ne.jp\" || body=\"@cap.bbiq.jp\" || body=\"@ninus.ocn.ne.jp\" || body=\"@mf.scn-net.ne.jp\" || body=\"@sky.plala.or.jp\" || body=\"@re.commufa.jp\" || body=\"@sadakari-isu.co.jp\" || body=\"@jcom.home.ne.jp\" || body=\"@toppen.jp\")"),
            _ => String::from("country=\"JP\" && (body=\"@docomo.ne.jp\" || body=\"@icloud.com\" || body=\"@po8.oninet.ne.jp\" || body=\"@softbank.ne.jp\" || body=\"@hidaka-print.com\" || body=\"@ac.auone-net.jp\" || body=\"@nifty.com\" || body=\"@kjd.biglobe.ne.jp\" || body=\"@cap.bbiq.jp\" || body=\"@ninus.ocn.ne.jp\" || body=\"@mf.scn-net.ne.jp\" || body=\"@sky.plala.or.jp\" || body=\"@re.commufa.jp\" || body=\"@sadakari-isu.co.jp\" || body=\"@jcom.home.ne.jp\" || body=\"@toppen.jp\")"),
        }
    }
    
    fn make_request(&self, query: &str, page: usize) -> Result<FofaResponse, ScannerError> {
        let url = format!(
            "{}?email={}&key={}&qbase64={}&page={}&size={}&fields=host,title,ip,domain,port,country,city,server,protocol,banner",
            self.base_url,
            self.email,
            self.key,
            self.encode_query(query),
            page,
            self.page_size
        );
        
        let mut retries = 3;
        let delay = 2;
        
        while retries > 0 {
            match self.client.get(&url).send() {
                Ok(response) => {
                    if response.status().is_success() {
                        match response.json::<FofaResponse>() {
                            Ok(data) => return Ok(data),
                            Err(e) => {
                                // 记录JSON解析错误
                                eprintln!("JSON解析错误: {}", e);
                            }
                        }
                    } else {
                        // 记录HTTP状态码错误
                        eprintln!("HTTP错误状态码: {}", response.status());
                    }
                },
                Err(e) => {
                    // 记录请求错误
                    eprintln!("请求错误: {}", e);
                }
            }
            
            // 如果执行到这里，说明JSON解析失败
            retries -= 1;
            thread::sleep(Duration::from_secs(delay));
        }
        
        Err(ScannerError::Other("请求失败，已重试多次".to_string()))
    }
    
    fn extract_emails_from_page(&self, url_str: &str) -> Vec<String> {
        let mut emails = Vec::new();
        
        // 修复URL格式问题
        let url_str = if url_str.contains("http://http") {
            url_str.replace("http://http", "http")
        } else if url_str.contains("https://http") {
            url_str.replace("https://http", "http")
        } else if !url_str.starts_with("http") {
            format!("http://{}", url_str)
        } else {
            url_str.to_string()
        };
        
        // 解析URL
        let url = match Url::parse(&url_str) {
            Ok(u) => u,
            Err(e) => {
                warn!("无效URL {}: {}", url_str, e);
                return emails;
            }
        };
        
        // 定义允许的域名列表
        let allowed_domains = [
            "icloud.com", "po8.oninet.ne.jp", "softbank.ne.jp", 
            "hidaka-print.com", "ac.auone-net.jp", "nifty.com", "kjd.biglobe.ne.jp", 
            "cap.bbiq.jp", "ninus.ocn.ne.jp", "mf.scn-net.ne.jp", "sky.plala.or.jp", 
            "re.commufa.jp", "sadakari-isu.co.jp", "jcom.home.ne.jp", "toppen.jp"
        ];
        
        // 添加请求头，模拟浏览器
        for attempt in 0..3 {
            match self.client.get(url.as_str())
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.5")
                .header("Connection", "keep-alive")
                .header("Upgrade-Insecure-Requests", "1")
                .send() {
                Ok(response) => {
                    if response.status().is_success() {
                        if let Ok(content) = response.text() {
                            // 提取所有可能的邮箱
                            let found_emails: HashSet<_> = self.personal_email_pattern.find_iter(&content)
                                .map(|m| m.as_str().to_string())
                                .collect();
                            
                            for email in found_emails {
                                // 只保留符合指定域名的邮箱
                                if let Some(domain_part) = email.split('@').nth(1) {
                                    if allowed_domains.iter().any(|&domain| domain_part == domain) {
                                        info!("发现邮箱: {}", email);
                                        emails.push(email);
                                    }
                                }
                            }
                        }
                        break;
                    } else if response.status().as_u16() == 403 {
                        warn!("访问被拒绝(403) {}", url);
                        break;
                    } else {
                        warn!("HTTP错误 {}: {} - 尝试 {}/3", url, response.status(), attempt + 1);
                    }
                },
                Err(e) => {
                    warn!("请求错误 {}: {} - 尝试 {}/3", url, e, attempt + 1);
                    thread::sleep(Duration::from_secs(2));
                }
            }
        }
        
        emails
    }
    
    fn process_hosts(&self, hosts: Vec<String>) -> Vec<EmailResult> {
        let mut results = Vec::new();
        let (tx, rx) = mpsc::channel();
        
        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(self.max_workers)
            .build()
            .unwrap();
        
        for host_str in hosts {
            let host_clone = host_str.clone();
            let tx_clone = tx.clone();
            let scanner_clone = self.clone();
            
            pool.spawn(move || {
                // 添加随机延迟避免请求过快
                thread::sleep(Duration::from_millis(thread_rng().gen_range(100..500)));
                
                // 确保URL格式正确
                let url = if host_clone.starts_with("http://") || host_clone.starts_with("https://") {
                    host_clone.clone()
                } else {
                    format!("http://{}", host_clone)
                };
                
                // 因为extract_emails_from_page返回Vec而不是Result，直接处理
                let emails = scanner_clone.extract_emails_from_page(&url);
                for email in emails {
                    let _ = tx_clone.send(EmailResult {
                        host: host_clone.clone(),
                        email: email,
                    });
                }
            });
        }
        
        // 等待所有线程完成并收集结果
        drop(tx);
        
        for email in rx {
            results.push(email);
        }
        
        results
    }
    
    fn scan(&self, query_types: Option<Vec<String>>) -> Vec<EmailResult> {
        let query_types = match query_types {
            Some(types) => types,
            None => vec![
                "default".to_string(), 
                "domain".to_string(), 
                "contact".to_string(), 
                "form".to_string(), 
                "profile".to_string(), 
                "personal".to_string(),
                "specific_jp_emails".to_string()
            ],
        };
        
        let mut all_hosts: HashSet<String> = HashSet::new();
        
        for query_type in &query_types {
            info!("正在使用查询类型: {}", query_type);
            let query = self.build_query(query_type);
            info!("FOFA查询语法: {}", query);
            
            for page in 1..=self.max_page {
                info!("正在获取第 {} 页结果...", page);
                match self.make_request(&query, page) {
                    Ok(data) => {
                        if let Some(results) = &data.results {
                            if results.is_empty() {
                                info!("没有更多结果或API限制达到，停止查询类型 {}", query_type);
                                break;
                            }
                            
                            let hosts: Vec<String> = results.iter()
                                .filter_map(|result| {
                                    if result.is_empty() {
                                        None
                                    } else {
                                        Some(result[0].clone())
                                    }
                                })
                                .collect();
                                
                            for host in hosts {
                                all_hosts.insert(host);
                            }
                        } else {
                            info!("API返回为空");
                            break;
                        }
                    },
                    Err(e) => {
                        error!("API请求失败: {:?}", e);
                        break;
                    }
                }
                
                // API速率限制
                thread::sleep(Duration::from_secs(2));
            }
        }
        
        info!("共发现 {} 个唯一主机", all_hosts.len());
        let hosts_list: Vec<String> = all_hosts.into_iter().collect();
        
        // 批量处理以避免内存问题
        let batch_size = 100;
        let mut all_emails = Vec::new();
        
        for (i, batch) in hosts_list.chunks(batch_size).enumerate() {
            info!("处理批次 {}/{}...", i + 1, (hosts_list.len() + batch_size - 1) / batch_size);
            let batch_emails = self.process_hosts(batch.to_vec());
            all_emails.extend(batch_emails);
        }
        
        let mut results = self.results.lock().unwrap();
        *results = all_emails.clone();
        
        info!("扫描完成，共提取 {} 个日本邮箱", all_emails.len());
        all_emails
    }
    
    fn save_to_csv(&self, filename: &str) -> Result<(), ScannerError> {
        let results = self.results.lock().unwrap();
        
        if results.is_empty() {
            warn!("没有结果可保存");
            return Ok(());
        }
        
        let mut writer = Writer::from_path(filename)?;
        
        writer.write_record(&["host", "email"])?;
        for result in results.iter() {
            writer.write_record(&[&result.host, &result.email])?;
        }
        
        writer.flush()?;
        info!("结果已保存到 {}", filename);
        
        Ok(())
    }
    
    fn save_to_json(&self, filename: &str) -> Result<(), ScannerError> {
        let results = self.results.lock().unwrap();
        
        if results.is_empty() {
            warn!("没有结果可保存");
            return Ok(());
        }
        
        let json = serde_json::to_string_pretty(&*results)?;
        let mut file = File::create(filename)?;
        file.write_all(json.as_bytes())?;
        
        info!("结果已保存到 {}", filename);
        
        Ok(())
    }

    fn extract_emails(&self, host: &str, content: &str) -> Vec<EmailResult> {
        let mut results = Vec::new();
        
        // 添加这段代码：定义允许的域名列表
        let allowed_domains = [
            "docomo.ne.jp", "icloud.com", "po8.oninet.ne.jp", "softbank.ne.jp", 
            "hidaka-print.com", "ac.auone-net.jp", "nifty.com", "kjd.biglobe.ne.jp", 
            "cap.bbiq.jp", "ninus.ocn.ne.jp", "mf.scn-net.jp", "sky.plala.or.jp", 
            "re.commufa.jp", "sadakari-isu.co.jp", "jcom.home.ne.jp", "toppen.jp"
        ];
        
        // 使用unwrap_or_else替代可能返回Err的方式
        let email_regex = match regex::Regex::new(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}") {
            Ok(re) => re,
            Err(e) => {
                eprintln!("正则表达式编译错误: {}", e);
                return vec![];  // 返回空向量而不是Err
            }
        };
        
        let emails = email_regex.find_iter(content);
        
        for email_match in emails {
            let email = email_match.as_str();
            // 检查邮箱是否使用了允许的域名之一
            if let Some(domain_part) = email.split('@').nth(1) {
                if allowed_domains.iter().any(|&domain| domain_part.ends_with(domain)) {
                    results.push(EmailResult {
                        host: host.to_string(),
                        email: email.to_string(),
                    });
                }
            }
        }
        
        return results;
    }
}

fn main() -> Result<(), ScannerError> {
    // 配置日志
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info"))
        .format_timestamp_secs()
        .init();
    
    // 解析命令行参数
    let args = Args::parse();
    
    // 创建扫描器
    let scanner = FofaScanner::new(
        args.email,
        args.key,
        args.max_page,
        args.page_size,
        args.workers
    );
    
    // 执行扫描
    scanner.scan(args.query_types);
    
    // 保存结果
    scanner.save_to_csv(&format!("{}.csv", args.output))?;
    scanner.save_to_json(&format!("{}.json", args.output))?;
    
    Ok(())
} 