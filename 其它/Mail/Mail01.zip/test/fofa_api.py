import requests
import base64
import re
import time
import argparse
import csv
import json
import logging
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import random
import urllib3
from bs4 import BeautifulSoup
import unicodedata


# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("fofa_scan.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class FofaScanner:
    def __init__(self, email, key, max_page=100, page_size=100, timeout=10, max_workers=10):
        self.email = email
        self.key = key
        self.max_page = max_page
        self.page_size = page_size
        self.timeout = timeout
        self.max_workers = max_workers
        self.base_url = "http://107.173.248.176:18888/api/v1/search/all"
        
        # 更精确的邮箱正则匹配模式
        self.email_pattern = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
        
        # 日本常见姓氏列表（用于验证可能的日本人邮箱）
        self.jp_surnames = [
            'suzuki', 'tanaka', 'yamamoto', 'watanabe', 'ito', 'sato', 'takahashi', 
            'yamada', 'nakamura', 'kobayashi', 'kato', 'yoshida', 'yamashita', 'sasaki', 
            'yamaguchi', 'matsumoto', 'inoue', 'kimura', 'hayashi', 'shimizu', 'saito', 
            'yamazaki', 'abe', 'mori', 'ikeda', 'hashimoto', 'ishikawa', 'nakajima', 
            'maeda', 'fujita', 'ogawa', 'goto', 'okada', 'hasegawa', 'murakami', 
            'kondo', 'ishii', 'sakamoto', 'endo', 'aoki', 'fujii', 'nishimura', 
            'fukuda', 'ota', 'miura', 'fujiwara', 'okamoto', 'matsuda', 'nakagawa'
        ]
        
        # 系统邮箱关键词
        self.system_email_keywords = [
            'noreply', 'no-reply', 'support', 'info', 'admin', 'contact', 'service', 
            'webmaster', 'postmaster', 'sales', 'inquiry', 'help', 'office', 'mail', 
            'webinfo', 'staff', 'master', 'system', 'notification', 'marketing'
        ]
        
        # 日本常用邮箱域名
        self.jp_email_domains = [
            'yahoo.co.jp', 'gmail.com', 'outlook.jp', 'outlook.com', 'hotmail.co.jp',
            'icloud.com', 'docomo.ne.jp', 'ezweb.ne.jp', 'au.com', 'softbank.ne.jp',
            'i.softbank.jp', 'ymobile.ne.jp', 'ybb.ne.jp', 'ocn.ne.jp', 'nifty.com',
            'live.jp', 'excite.co.jp', 'goo.jp', 'jp'
        ]
        
        self.results = []
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
    def _encode_query(self, query):
        """Base64编码查询字符串"""
        return base64.b64encode(query.encode()).decode()
    
    def _build_query(self, query_type):
        """根据不同的查询类型构建FOFA搜索语法"""
        if query_type == "domain":
            # 搜索日本域名网站
            return 'domain=".jp" && country="JP"'
        elif query_type == "contact":
            # 搜索包含联系方式的页面
            return 'country="JP" && (body="お問い合わせ" || body="contact" || body="メール" || body="連絡先")'
        elif query_type == "staff":
            # 搜索公司职员页面
            return 'country="JP" && (body="スタッフ" || body="社員" || body="従業員" || body="メンバー" || body="team" || body="staff")'
        elif query_type == "personal":
            # 搜索个人页面
            return 'country="JP" && (body="プロフィール" || body="自己紹介" || body="担当者" || body="個人情報")'
        elif query_type == "academic":
            # 搜索学术机构页面
            return 'country="JP" && (body="大学" || body="研究室" || body="研究者" || body="教授" || body="准教授" || body="講師")'
        elif query_type == "blog":
            # 搜索个人博客
            return 'country="JP" && (body="ブログ" || body="blog" || body="日記" || body="diary")'
        else:
            # 默认搜索包含邮箱的页面
            return 'country="JP" && (body="@*.jp" || body="@gmail.com" || body="@yahoo.co.jp" || body="@outlook.jp")'
    
    def _make_request(self, query, page=1):
        """发送API请求并获取结果"""
        params = {
            'email': self.email,
            'key': self.key,
            'qbase64': self._encode_query(query),
            'page': page,
            'size': self.page_size,
            'fields': 'host,title,ip,domain,port,country,city,server,protocol,banner'
        }
        
        try:
            response = requests.get(self.base_url, params=params, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"请求失败: {str(e)}")
            return None
    
    def _is_japanese_name(self, name):
        """判断用户名是否可能是日本人姓名"""
        name = name.lower()
        
        # 检查是否包含常见日本姓氏
        for surname in self.jp_surnames:
            if surname in name or name in surname:
                return True
        
        # 检查是否包含日语字符
        try:
            for char in name:
                char_name = unicodedata.name(char, '')
                if 'HIRAGANA' in char_name or 'KATAKANA' in char_name or 'CJK' in char_name:
                    return True
        except:
            pass
            
        return False
    
    def _is_system_email(self, email):
        """判断是否是系统邮箱"""
        username = email.split('@')[0].lower()
        
        # 检查是否包含系统邮箱关键词
        for keyword in self.system_email_keywords:
            if keyword in username:
                return True
                
        # 检查是否只包含数字
        if username.isdigit():
            return True
            
        # 检查是否过短（通常个人邮箱名字较长）
        if len(username) <= 2:
            return True
            
        return False
    
    def _extract_emails_from_page(self, url):
        """从网页内容中提取日本人邮箱"""
        try:
            # 修复URL格式问题
            if 'http://' in url[7:] or 'https://' in url[7:]:
                url = re.sub(r'http://https?://', 'https://', url)
                url = re.sub(r'https://https?://', 'https://', url)
            
            # 添加请求头，模拟浏览器
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',  # 添加日语语言支持
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Cache-Control': 'max-age=0'
            }
            
            # 增加超时设置和重试机制
            for attempt in range(3):  # 最多重试3次
                try:
                    response = requests.get(url, headers=headers, timeout=self.timeout, verify=False)
                    response.raise_for_status()
                    content = response.text
                    
                    # 使用BeautifulSoup解析HTML
                    soup = BeautifulSoup(content, 'html.parser')
                    
                    # 移除不可能包含个人邮箱的元素
                    for script in soup(['script', 'style', 'noscript', 'head', 'meta', 'link']):
                        script.decompose()
                    
                    # 提取纯文本内容
                    text_content = soup.get_text(' ', strip=True)
                    
                    # 提取所有可能的邮箱
                    all_emails = set(re.findall(self.email_pattern, text_content))
                    
                    # 过滤出可能的日本人个人邮箱
                    jp_personal_emails = []
                    
                    for email in all_emails:
                        username, domain = email.split('@')
                        
                        # 跳过系统邮箱
                        if self._is_system_email(email):
                            continue
                            
                        # 检查域名是否是日本常用邮箱服务或者.jp域名
                        is_jp_domain = domain.endswith('.jp') or any(jp_domain in domain.lower() for jp_domain in self.jp_email_domains)
                        
                        if not is_jp_domain:
                            continue
                            
                        # 检查用户名是否可能是日本人姓名
                        if self._is_japanese_name(username):
                            jp_personal_emails.append(email)
                            continue
                            
                        # 额外检查：在页面中查找邮箱附近的文本，判断是否可能是个人邮箱
                        email_index = text_content.find(email)
                        if email_index > 0:
                            context = text_content[max(0, email_index-100):min(len(text_content), email_index+100)]
                            
                            # 检查上下文是否包含日本人名称相关词汇
                            jp_keywords = ['さん', '様', '先生', '教授', '担当', '氏']
                            if any(keyword in context for keyword in jp_keywords):
                                jp_personal_emails.append(email)
                    
                    return jp_personal_emails
                    
                except requests.exceptions.HTTPError as e:
                    if e.response.status_code == 403:
                        logger.warning(f"访问被拒绝(403) {url}")
                        break  # 直接跳出，403一般重试也没用
                    logger.warning(f"HTTP错误 {url}: {e} - 尝试 {attempt+1}/3")
                except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
                    logger.warning(f"连接错误 {url}: {e} - 尝试 {attempt+1}/3")
                    time.sleep(2)  # 重试前等待
                except Exception as e:
                    logger.warning(f"未知错误 {url}: {e} - 尝试 {attempt+1}/3")
                    time.sleep(1)
            
            return []
        except Exception as e:
            logger.error(f"提取邮箱失败 {url}: {str(e)}")
            return []
    
    def _process_hosts(self, hosts):
        """处理主机列表并提取邮箱"""
        emails = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_url = {}
            for host in hosts:
                # 确保URL格式正确
                if host.startswith('https://') or host.startswith('http://'):
                    url = host
                else:
                    url = f"http://{host}"
                
                # 添加随机延迟避免请求过快被封
                time.sleep(random.uniform(0.5, 1.5))
                future_to_url[executor.submit(self._extract_emails_from_page, url)] = host
            
            for future in tqdm(future_to_url, desc="提取邮箱"):
                host = future_to_url[future]
                try:
                    result = future.result()
                    if result:
                        for email in result:
                            emails.append({
                                "host": host,
                                "email": email
                            })
                            logger.info(f"发现邮箱: {email} (来源: {host})")
                except Exception as e:
                    logger.error(f"处理 {host} 时出错: {str(e)}")
        return emails
    
    def scan(self, query_types=None):
        """执行扫描并返回结果"""
        if query_types is None:
            query_types = ["default", "domain", "contact", "staff", "personal", "academic", "blog"]
            
        all_hosts = set()
        
        for query_type in query_types:
            logger.info(f"正在使用查询类型: {query_type}")
            query = self._build_query(query_type)
            logger.info(f"FOFA查询语法: {query}")
            
            for page in range(1, self.max_page + 1):
                logger.info(f"正在获取第 {page} 页结果...")
                data = self._make_request(query, page)
                
                if not data or "results" not in data or not data["results"]:
                    logger.info(f"没有更多结果或API限制达到，停止查询类型 {query_type}")
                    break
                
                hosts = [result[0] for result in data["results"]]
                all_hosts.update(hosts)
                
                # API速率限制
                time.sleep(3)  # 增加请求间隔
        
        logger.info(f"共发现 {len(all_hosts)} 个唯一主机")
        hosts_list = list(all_hosts)
        
        # 批量处理以避免内存问题
        batch_size = 50  # 减小批处理大小
        all_emails = []
        
        for i in range(0, len(hosts_list), batch_size):
            batch = hosts_list[i:i+batch_size]
            logger.info(f"处理批次 {i//batch_size + 1}/{(len(hosts_list)+batch_size-1)//batch_size}...")
            emails = self._process_hosts(batch)
            all_emails.extend(emails)
            time.sleep(5)  # 批次之间增加等待时间
            
        # 移除重复邮箱
        unique_emails = []
        seen_emails = set()
        
        for item in all_emails:
            if item['email'].lower() not in seen_emails:
                seen_emails.add(item['email'].lower())
                unique_emails.append(item)
        
        self.results = unique_emails
        logger.info(f"扫描完成，共提取 {len(unique_emails)} 个日本人个人邮箱")
        return unique_emails
    
    def save_to_csv(self, filename="jp_emails.csv"):
        """保存结果到CSV文件"""
        if not self.results:
            logger.warning("没有结果可保存")
            return
            
        try:
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['host', 'email']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                for result in self.results:
                    writer.writerow(result)
            logger.info(f"结果已保存到 {filename}")
        except Exception as e:
            logger.error(f"保存到CSV失败: {str(e)}")
    
    def save_to_json(self, filename="jp_emails.json"):
        """保存结果到JSON文件"""
        if not self.results:
            logger.warning("没有结果可保存")
            return
            
        try:
            with open(filename, 'w', encoding='utf-8') as jsonfile:
                json.dump(self.results, jsonfile, ensure_ascii=False, indent=4)
            logger.info(f"结果已保存到 {filename}")
        except Exception as e:
            logger.error(f"保存到JSON失败: {str(e)}")

def main():
    parser = argparse.ArgumentParser(description='FOFA日本邮箱扫描工具')
    parser.add_argument('-e', '--email', required=True, help='FOFA账户邮箱')
    parser.add_argument('-k', '--key', required=True, help='FOFA API密钥')
    parser.add_argument('-p', '--max-page', type=int, default=10, help='最大扫描页数')
    parser.add_argument('-s', '--page-size', type=int, default=100, help='每页结果数')
    parser.add_argument('-t', '--query-types', nargs='+', default=None, 
                        help='查询类型 (default, domain, contact, staff, personal, academic, blog)')
    parser.add_argument('-w', '--workers', type=int, default=10, help='并发工作线程数')
    parser.add_argument('-o', '--output', default='jp_emails', help='输出文件名（不含扩展名）')
    
    args = parser.parse_args()
    
    scanner = FofaScanner(
        email=args.email,
        key=args.key,
        max_page=args.max_page,
        page_size=args.page_size,
        max_workers=args.workers
    )
    
    scanner.scan(query_types=args.query_types)
    scanner.save_to_csv(f"{args.output}.csv")
    scanner.save_to_json(f"{args.output}.json")

if __name__ == "__main__":
    main()