# SQLi-Dorks-Generator
Here we go!
You are a cracker and you want to make good dorks easily  to search vulnerable sites with google search engine?
This tool is what it does for you! Coded by X-Slayer, you can make some dorks file with yuor page name. Example: index and followed by 
extensions like .php .asp .aspx and others.... 
Then you can try to hack database with SQL Injection to retrivie good and personal Combolist to crack accounts! 
Enjoy!

