﻿function openhide(dmobid,dmobms){
 document.getElementById(dmobid).style.display=dmobms;
}
function sharelistdiv(){
 if(document.getElementById("fszxc").style.display=="block"){
	 document.getElementById("fszxc").style.display="none"
 }else{
	 document.getElementById("fszxc").style.display="block"
 }
}
function gjgzhdiv(){
 if(document.getElementById("gjgzh").style.display=="block"){
	 document.getElementById("gjgzh").style.display="none"
 }else{
	 document.getElementById("gjgzh").style.display="block"
 }
}